package Task1;


public class task4 {
    public  static  double getMax(double a, double b, double c) {
        double d = Math.max(a * b * c, a + b + c) + 3;
        return d;
    }
}
