package Task2.tests;

import Task2.task6;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class test6 {
    @Test
    public void t1() throws Exception{
        assertEquals(321, task6.getOtobraj(123),0);
    }
}
