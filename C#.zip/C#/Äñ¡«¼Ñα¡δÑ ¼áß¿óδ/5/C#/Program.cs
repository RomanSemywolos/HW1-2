﻿using System;

namespace DevEducation_3_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-якi 5 чисел:");
            int[] numbers = new int[5];
            int i = 0;
            for (i = 0; i < 5; i++)
            {
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            int sum = 0;
            i = 0;
            foreach (int a in numbers)
            {
                if(i % 2 != 0)
                {
                    sum += a;
                }
                i++;
            }
            Console.WriteLine("Сума елементiв масива з непарними iндексами = "+sum+"");
        }
    }
}
