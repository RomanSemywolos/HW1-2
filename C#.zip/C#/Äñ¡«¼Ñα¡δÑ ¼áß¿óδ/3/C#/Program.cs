﻿using System;
using System.Linq;

namespace DevEducation_3_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-якi 5 чисел:");
            int[] numbers = new int[5];
            int i = 0;
            for (i = 0; i < 5; i++)
            {
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("Найменше число знаходиться на такiй позицiї: ");
            int min = numbers.Min();
            int indexMin = Array.IndexOf(numbers, min);
            Console.Write(indexMin);
        }
    }
}