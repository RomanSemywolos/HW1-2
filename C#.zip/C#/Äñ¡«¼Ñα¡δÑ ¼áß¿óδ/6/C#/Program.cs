﻿using System;

namespace DevEducation_3_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-якi 5 чисел:");
            int[] numbers = new int[5];
            int i = 0;
            for (i = 0; i < 5; i++)
            {
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            int[] revers = new int[5];
            i = 4;
            foreach (int a in numbers)
            {
                if (i >= 0)
                {
                    revers[i] = a;
                    i--;
                }
            }
            Console.WriteLine("Реверс масиву:");
            foreach (int a in revers)
            {
                Console.Write(""+a+" ");
            }
        }
    }
}
