﻿using System;

namespace DevEducation_2._4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-яке число");
            int n = Convert.ToInt32(Console.ReadLine());
            int f = 1;
            for (int i = 2; i <= n; i++)
            {
                f = f * i;
            }
            Console.WriteLine("Факторiал з числа " + n + " = " + f + " ");
        }
    }
}