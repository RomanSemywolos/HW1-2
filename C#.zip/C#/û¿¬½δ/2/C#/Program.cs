﻿using System;

namespace DevEducation_2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            bool p = true;
            Console.Write("Введiть будь-яке число:");
            int a = Convert.ToInt32(Console.ReadLine());
            for (int i = 2; i <= a / 2; i++)
            {
                if (a % i == 0)
                {
                    p = false;
                    break;
                }
            }
            if (p & a > 1)
            {
                Console.WriteLine("Число просте");
            }
            else
            {
                Console.WriteLine("Число не просте");
            }
            Console.ReadKey();
        }
    }
}
