﻿using System;

namespace Deveducation_2._3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-яке число");
            double a = Convert.ToDouble(Console.ReadLine());
            double b = 0;
            for (double i = 0; i * i <= a; i += 0.1)
            {
                Console.WriteLine("Пошук кореня з числа "+a+":"+i+"");
                b = i;
            }
            Console.WriteLine(" Корiнь з числа " + a + " = " + Math.Round(b) + " ");
        }
    }
}
