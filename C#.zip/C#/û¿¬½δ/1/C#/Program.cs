﻿using System;

namespace DevEducation_2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int counter = 0;
            for (int i = 1; i < 99; i += 2)
            {
                sum += i;
                counter++;
            }
            Console.WriteLine(" Сума парних чисел вiд 1 до 99 дорiвнює: " + sum + " ");
            Console.WriteLine(" Кiлькiсть парних чисел вiд 1 до 99 дорiвнює: " + counter + " ");
        }
    }
}
