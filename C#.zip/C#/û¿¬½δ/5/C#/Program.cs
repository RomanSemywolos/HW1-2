﻿using System;

namespace DevEducation_2._5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-яке число");
            int a = Convert.ToInt32(Console.ReadLine());
            int b = 0;
            {
                for (int i = a; i > 0; b += i % 10, i /= 10) ;
            }
            Console.WriteLine("Сума цифр = "+b+"");
        }
    }
}