﻿using System;

namespace DevEducation_2._6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-яке число");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Вiдзеркалене число: ");
            for (int i = a % 10; a > 0; Console.Write(i), a /= 10, i = a % 10);
        }
    }
}
