﻿using System;

namespace DevEducation_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть будь-якi три числа");
            double a = Convert.ToDouble(Console.ReadLine());
            double b = Convert.ToDouble(Console.ReadLine());
            double c = Convert.ToDouble(Console.ReadLine());
            double d = a + b + c;
            double e = a * b * c;
            if (d > e)
            {
                double f = d + 3;
                Console.WriteLine("Оскiльки " + a +"+"+ b +"+"+ c + " бiльше або дорiвнює " + a + "*" + b + "*" + c + ", то вiдповiдь "+ f +" ");
            }
            else
            {
                double f = e + 3;
                Console.WriteLine("Оскiльки " + a + "*" + b + "*" + c + " бiльше або дорiвнює " + a + "+" + b + "+" + c + ", то вiдповiдь " + f + " ");
            }
            Console.ReadLine();
        }
    }
}