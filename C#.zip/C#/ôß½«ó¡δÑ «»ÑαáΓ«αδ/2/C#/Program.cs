﻿using System;

namespace DevEducation_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("x = ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("y = ");
            int y = Convert.ToInt32(Console.ReadLine());
            string a;
            if (y > 0)
            {
                if (x > 0)
                    a = "I";
                else               
                    a = "II";
            }
            else
            {
                if (x < 0)
                    a = "III";
                else           
                    a = "IV";
            }
            Console.WriteLine("Точка нележить {a} чвертi");
            Console.ReadLine();
        }
    }
}
