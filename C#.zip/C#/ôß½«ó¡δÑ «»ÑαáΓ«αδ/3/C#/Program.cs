﻿using System;

namespace DevEducation_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть три будь-яких числа");
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int c = Convert.ToInt32(Console.ReadLine());
            int d;
            if (a < 0)
            {
                a = 0;
            }
            if (b < 0)
            {
                b = 0;
            }
            if (c < 0)
            {
                c = 0;
            }
            d = a + b + c;
            Console.WriteLine("Сума додатнiх чисел = " + d + " ");
            Console.ReadKey();
        }
    }
}
