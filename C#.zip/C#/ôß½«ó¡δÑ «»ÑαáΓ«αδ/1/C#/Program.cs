﻿using System;

namespace DevEducation_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введiть два будь-яких числа");
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int c;
            if (a % 2 == 0)
            {
                c = a * b;
                Console.WriteLine(" " + a + "*" + b + "=" + c + " ");
            }
            else
            {
                c = a + b;
                Console.WriteLine(" " + a + "+" + b + "=" + c + " ");
            }
            Console.ReadKey();
        }
    }
}