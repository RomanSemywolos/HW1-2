﻿using System;

namespace DevEducation_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введiть рейтинг студента:");
            int r = Convert.ToInt32(Console.ReadLine());
            string v;
            if (r >= 0 & r <= 19)
            {
                v = "F";
            }
            else if (r >= 20 & r <= 39)
            {
                v = "E";
            }
            else if (r >= 40 & r <= 59)
            {
                v = "D";
            }
            else if (r >= 60 & r <= 74)
            {
                v = "C";
            }
            else if (r >= 75 & r <= 89)
            {
                v = "B";
            }
            else if (r >= 90 & r <= 100)
            {
                v = "A";
            }
            else
            {
                v = "Помилка";
            }
            Console.WriteLine(v);
        }
    }
}
